package steps;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.But;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {
	
	public ChromeDriver driver;
	
	@Given("User opens the chrome browser")
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@Given("User load the leaftaps Prod URL")
	public void loadURL() {
		driver.get("http://leaftaps.com/opentaps/control/main");
	}
	
	@Given("User maximise the browser")
	public void maxBrowser() {
		driver.manage().window().maximize();
	}
	
	@Given("User Set the default implicit timeout")
	public void setTimeouts() {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	@Given("User enters the username as (.*) in the loginpage")
	public void enterUserName(String userName) {
		driver.findElementById("username").sendKeys(userName);
	}
	
	@Given("User enters the password as (.*) in the loginpage")
	public void enterPassword(String password) {
		driver.findElementById("password").sendKeys(password);
	}
	
	@When("User click the Login button in the Loginpage")
	public void clickLogin() {
		driver.findElementByClassName("decorativeSubmit").click();
	}
	
	@Then("User should able to see the homepage")
	public void verifyLogin() {
		System.out.println("Login is Success");
	}
	
	@But("User should be in the Loginpage itself")
	public void verifyLoginFailure() {
		System.out.println("Login is Failed");
	}

}
