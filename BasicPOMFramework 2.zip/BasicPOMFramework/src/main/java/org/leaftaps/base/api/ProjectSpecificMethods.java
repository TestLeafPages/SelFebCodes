package org.leaftaps.base.api;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.leaftaps.utils.ReadExcel;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;



public class ProjectSpecificMethods {
	
	public RemoteWebDriver driver;
	public String excelName;
	public Properties prop;
	
	
	@BeforeSuite
	public void loadObjects() throws FileNotFoundException, IOException {
		prop = new Properties();
		prop.load(new FileInputStream("./eng.properties"));
	}
	

	@Parameters({"url"})
	@BeforeMethod
	public void login(String url) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);				
	}
	
	@AfterMethod
	public void closeApp() {
		driver.close();
	}
	
	// for dataProvider
	@DataProvider
	public String[][] getData() throws IOException {		
		ReadExcel data = new ReadExcel();
		return data.readExcel(excelName);
		
	}
	
	
	/*
	 * String[][] data = new String[2][4];
	 *  
	 * data[0][0] = "TestLeaf"; 
	 * data[0][1] = "Sarath";
	 * data[0][2] = "K";
	 * data[0][3] = "12345";
	 * data[1][0] = "TL";
	 * data[1][1] = "Babu"; 
	 * data[1][2] = "M"; 
	 * data[1][3] = "45678";
	 * 
	 * return data;		 */

}
