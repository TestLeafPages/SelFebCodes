package org.leaftaps.pages;

import org.leaftaps.base.api.ProjectSpecificMethods;
import org.openqa.selenium.remote.RemoteWebDriver;

public class LoginPage extends ProjectSpecificMethods{
	
	
	public LoginPage(RemoteWebDriver driver) {
		this.driver = driver;
	}
	
	
	public LoginPage enterUserName(String data) {
		driver.findElementById(prop.getProperty("login.uName.id")).sendKeys(data);
		return this;
	}
	
	public LoginPage enterPassword(String data) {
		driver.findElementById(prop.getProperty("lgoin.pwd.id")).sendKeys(data);
		return this;
	}
	
	public HomePage clickLogin() {
		driver.findElementByClassName(prop.getProperty("login.loginB.className")).click();
		return new HomePage(driver);		
	}
	
	public LoginPage clickLoginForFailure() {
		driver.findElementByClassName("decorativeSubmit").click();
		return this;		
	}
	
	public LoginPage verifyErrorMsg(String data) {
		if(driver.findElementById("errorDiv").getText().contains(data)){
			System.out.println("Credential wrong");
		}
		return this;
	}

}
