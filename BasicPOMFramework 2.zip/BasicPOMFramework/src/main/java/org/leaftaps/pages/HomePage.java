package org.leaftaps.pages;

import org.leaftaps.base.api.ProjectSpecificMethods;
import org.openqa.selenium.remote.RemoteWebDriver;

public class HomePage extends ProjectSpecificMethods{	
	
	
	public HomePage(RemoteWebDriver driver) {
		this.driver = driver;
	}
		
	public LoginPage clickLogut() {
		driver.findElementByClassName("decorativeSubmit").click();
		return new LoginPage(driver); 
	}

}
