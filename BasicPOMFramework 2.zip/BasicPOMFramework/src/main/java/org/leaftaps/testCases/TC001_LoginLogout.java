package org.leaftaps.testCases;

import org.leaftaps.base.api.ProjectSpecificMethods;
import org.leaftaps.pages.LoginPage;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC001_LoginLogout extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setData() {
		excelName = "TC001_LoginLogout";
	}
	
	@Test(dataProvider = "getData")
	public void loginLogout(String uName, String pwd) {			
		new LoginPage(driver)
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickLogut();	
		
	}

}
