package org.leaftaps.testCases;

import org.leaftaps.base.api.ProjectSpecificMethods;
import org.leaftaps.pages.LoginPage;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC001_LoginforFailure extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setData() {
		excelName = "TC002_LoginforFailure";
	}
	
	@Test(dataProvider = "getData")
	public void loginLogout(String uName, String pwd, String error) {			
		new LoginPage(driver)
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLoginForFailure()
		.verifyErrorMsg(error);
			
		
	}

}
