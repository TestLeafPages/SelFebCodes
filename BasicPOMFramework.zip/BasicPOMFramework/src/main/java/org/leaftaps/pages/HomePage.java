package org.leaftaps.pages;

import org.leaftaps.base.api.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods{	
		
	public LoginPage clickLogut() {
		driver.findElementByClassName("decorativeSubmit").click();
		return new LoginPage(); 
	}
	
	public void clickCRMSFA() {
		
	}

}
